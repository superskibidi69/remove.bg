"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useDropzone } from "react-dropzone"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Loader2, Upload, Download, LinkIcon } from "lucide-react"

export default function BackgroundRemover() {
  const [originalImage, setOriginalImage] = useState<string | null>(null)
  const [processedImage, setProcessedImage] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [imageUrl, setImageUrl] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      "image/*": [".jpeg", ".jpg", ".tiff", ".png", ".webp"],
    },
    maxFiles: 1,
    onDrop: async (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        handleImageUpload(acceptedFiles[0])
      }
    },
  })

  const handleImageUpload = async (file: File) => {
    const reader = new FileReader()

    reader.onload = () => {
      setOriginalImage(reader.result as string)
      setProcessedImage(null)
      processImage(reader.result as string)
    }

    reader.readAsDataURL(file)
  }

  const handleUrlSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!imageUrl) return

    setOriginalImage(imageUrl)
    setProcessedImage(null)
    processImage(imageUrl)
  }

  const processImage = async (imageSrc: string) => {
    setIsProcessing(true)

    try {
      const formData = new FormData()

      // For URL images
      if (imageSrc.startsWith("http")) {
        formData.append("imageUrl", imageSrc)
      }
      // For data URLs (from file upload)
      else {
        // Convert data URL to blob
        const response = await fetch(imageSrc)
        const blob = await response.blob()
        formData.append("image", blob)
      }

      console.log("Sending request to remove background API...")
      const response = await fetch("/api/remove-background", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        console.error("API Error:", errorData)
        throw new Error(errorData.details || "Failed to remove background")
      }

      const blob = await response.blob()
      setProcessedImage(URL.createObjectURL(blob))
    } catch (error) {
      console.error("Error removing background:", error)
      alert("Failed to remove background: " + (error instanceof Error ? error.message : "Unknown error"))
    } finally {
      setIsProcessing(false)
    }
  }

  const downloadImage = () => {
    if (!processedImage) return

    const link = document.createElement("a")
    link.href = processedImage
    link.download = "removed-background.png"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const handlePaste = async (e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items
    if (!items) return

    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf("image") !== -1) {
        const file = items[i].getAsFile()
        if (file) handleImageUpload(file)
        break
      }
    }
  }

  const resetState = () => {
    setOriginalImage(null)
    setProcessedImage(null)
    setIsProcessing(false)
    setImageUrl("")
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-center items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-700 rounded flex items-center justify-center">
              <div className="w-6 h-6 bg-gray-200 rounded-sm transform rotate-12"></div>
            </div>
            <span className="text-xl font-medium">
              remove<span className="text-gray-400">bg</span>
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-12 md:py-20">
        {!processedImage ? (
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">Remove Image Background</h1>
              <p className="text-lg text-gray-600">
                100% Automatically and{" "}
                <span className="bg-yellow-200 px-2 py-1 rounded text-yellow-800 font-medium">Free</span>
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8 relative overflow-hidden">
              {/* Yellow decorative elements */}
              <div className="absolute top-0 right-0 w-32 h-32 -mt-10 -mr-10 text-yellow-300 opacity-50">
                <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20,50 Q35,20 50,50 T80,50" stroke="currentColor" strokeWidth="6" fill="none" />
                </svg>
              </div>

              <div
                {...getRootProps()}
                className="border-2 border-dashed border-gray-300 rounded-lg p-10 text-center cursor-pointer hover:bg-gray-50 transition-colors"
                onPaste={handlePaste}
              >
                <input {...getInputProps()} ref={fileInputRef} />

                <Button
                  className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-6 rounded-full mb-6"
                  onClick={() => fileInputRef.current?.click()}
                >
                  Upload Image
                </Button>

                <p className="text-gray-500 mb-2">or drop a file,</p>

                <form onSubmit={handleUrlSubmit} className="flex items-center gap-2 max-w-md mx-auto mb-4">
                  <Input
                    type="text"
                    placeholder="paste image URL"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    className="flex-1"
                  />
                  <Button type="submit" size="sm" variant="outline">
                    <LinkIcon className="h-4 w-4" />
                  </Button>
                </form>

                {isDragActive && (
                  <div className="absolute inset-0 bg-blue-50 bg-opacity-90 flex items-center justify-center rounded-lg">
                    <p className="text-blue-500 font-medium text-lg">Drop your image here</p>
                  </div>
                )}
              </div>

              <div className="mt-8">
                <p className="text-gray-500 text-sm mb-2">No image? Try one of these:</p>
                <div className="grid grid-cols-4 gap-2">
                  {[1, 2, 3, 4].map((i) => (
                    <button
                      key={i}
                      className="aspect-square rounded-md overflow-hidden border hover:border-blue-500 transition-colors"
                      onClick={() => {
                        setOriginalImage(`/placeholder.svg?height=150&width=150`)
                        processImage(`/placeholder.svg?height=150&width=150`)
                      }}
                    >
                      <img
                        src={`/placeholder.svg?height=150&width=150`}
                        alt={`Sample ${i}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>

              <p className="text-xs text-gray-400 mt-6 text-center">
                By uploading an image or URL, you agree to our Terms of Service. To learn more about how remove.bg
                handles your personal data, check our Privacy Policy.
              </p>
            </div>
          </div>
        ) : (
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold">Background Removed</h2>
              <p className="text-gray-600">Download your image or edit further</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-lg shadow-md p-4">
                <div className="aspect-square bg-gray-100 rounded-md overflow-hidden">
                  {originalImage && (
                    <img
                      src={originalImage || "/placeholder.svg"}
                      alt="Original"
                      className="w-full h-full object-contain"
                    />
                  )}
                </div>
                <p className="mt-2 text-center font-medium">Original Image</p>
              </div>

              <div className="bg-white rounded-lg shadow-md p-4">
                <div className="aspect-square bg-[url('/placeholder.svg?height=400&width=400')] rounded-md overflow-hidden relative">
                  {isProcessing ? (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Loader2 className="h-12 w-12 animate-spin text-blue-500" />
                    </div>
                  ) : (
                    processedImage && (
                      <img
                        src={processedImage || "/placeholder.svg"}
                        alt="Processed"
                        className="w-full h-full object-contain"
                      />
                    )
                  )}
                </div>
                <p className="mt-2 text-center font-medium">Removed Background</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <Button onClick={resetState} variant="outline" className="gap-2">
                <Upload className="h-4 w-4" />
                Upload New Image
              </Button>

              <Button onClick={downloadImage} className="gap-2 bg-blue-500 hover:bg-blue-600">
                <Download className="h-4 w-4" />
                Download HD Image
              </Button>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t py-6">
        <div className="container mx-auto px-4 text-center text-gray-500 text-sm">
          © {new Date().getFullYear()} Background Remover. All rights reserved.
        </div>
      </footer>
    </div>
  )
}

