import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const imageFile = formData.get("image") as File
    const imageUrl = formData.get("imageUrl") as string

    if (!imageFile && !imageUrl) {
      return NextResponse.json({ error: "No image provided" }, { status: 400 })
    }

    const apiKey = "k117vCjAwCve241sHSxWfFSD" // Hardcoded for demo, use environment variable in production
    if (!apiKey) {
      return NextResponse.json({ error: "API key not configured" }, { status: 500 })
    }

    let requestBody: FormData | string = new FormData()

    if (imageFile) {
      requestBody.append("image_file", imageFile)
    } else if (imageUrl) {
      requestBody = JSON.stringify({ image_url: imageUrl })
    }

    const headers: HeadersInit = {
      "X-Api-Key": apiKey,
    }

    if (imageUrl) {
      headers["Content-Type"] = "application/json"
    }

    const response = await fetch("https://api.remove.bg/v1.0/removebg", {
      method: "POST",
      headers,
      body: requestBody,
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("Remove.bg API error:", errorText, "Status:", response.status)
      return NextResponse.json(
        {
          error: "Failed to remove background",
          details: errorText,
          status: response.status,
        },
        { status: response.status },
      )
    }

    const imageBuffer = await response.arrayBuffer()

    return new NextResponse(imageBuffer, {
      headers: {
        "Content-Type": "image/png",
        "Cache-Control": "public, max-age=86400",
      },
    })
  } catch (error) {
    console.error("Error in remove-background API route:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

